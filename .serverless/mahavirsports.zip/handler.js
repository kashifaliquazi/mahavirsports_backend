// 'use strict';
// const express = require('express');
// const serverless = require('serverless-http');
// const cors = require('cors');
// const bodyParser = require('body-parser');
// const morgan = require('morgan');

// const app = express();
// app.use(function(req, res, next) {if(req.originalUrl.startsWith('/pghandler/v1/firetvinapp')){req.rawBody = '';req.setEncoding('utf8');req.on('data', function(chunk){req.rawBody += chunk;});req.on('end', function(){next();});}else{next();}});
// app.use(function(req, res, next) {if(req.originalUrl.startsWith('/pghandler/v1/etisaletuae')){req.rawBody = '';req.setEncoding('utf8');req.on('data', function(chunk){req.rawBody += chunk;});req.on('end', function(){next();});}else{next();}});
// app.use(bodyParser.json({verify: function(req, res, buf) {if (req.originalUrl.startsWith('/callback/v1/razorpay')){req.rawBody = buf.toString();}},limit: '5mb'}));
// app.use(bodyParser.urlencoded({limit: '5mb', extended: true, parameterLimit:5000}));

// //Morgan Logger
// app.use(morgan('combined'));

// app.use(cors());
// app.options('*', cors());

// //Constants And Build Environment
// const constants = require('/opt/config/constant.js');
// const localconstants = require('./config/constant');
// const BUILD_STAGE = process.env.BUILD_STAGE || 'testv1';
// app.use(function (req, res, next){req.query.BUILD_STAGE = BUILD_STAGE; next();});
// app.use(function (req, res, next){req.query.serviceid = localconstants.serviceid; next();});
// app.use(function (req, res, next){req.query.servicekey = localconstants.servicekey; next();});

// //Get Country Details
// let getcountrycodeapi = require('/opt/maxmind/getcountrycodeapi');
// app.use(getcountrycodeapi.getCountryDetail);

// //General Service Details Setting
// //const mysqlconnpool = require('/opt/config/MysqlPool');
// //app.use(function (req, res, next){req.query.mysqlconnpool = mysqlconnpool; next();});

// //Redis Connection Handler
// const redisClient = require('/opt/config/RedisPool');
// app.use(function (req, res, next){req.query.redisClient = redisClient; next();});

// //Provider Related
// const providerauthapi = require('/opt/authapi/providerauthapi');
// app.use('/provider', function (req, res, next){req.query.service_redis_prefix = constants.RedisPrefixProviderVcharge; next();});
// app.use('/provider', function (req, res, next){req.query.service_db_name_suffix = constants.db_name_suffix_vcharge; next();});
// app.use('/provider', providerauthapi.providerAuthHandler);
// app.use('/provider', require('./routes/provider'));

// //SysAdmin Related
// const sysadminauthapi = require('/opt/authapi/sysadminauthapi');
// app.use('/sysadmin', function (req, res, next){req.query.service_redis_prefix = constants.RedisPrefixSysAdminVcharge; next();});
// app.use('/sysadmin', function (req, res, next){req.query.service_db_name_suffix = constants.vlive_gateway_db_name; next();});
// app.use('/sysadmin', sysadminauthapi.sysAdminAuthHandler);
// app.use('/sysadmin', require('./routes/sysadmin'));

// //Common SysAdmin Related
// app.use('/servicesysadmin', function (req, res, next){req.query.service_redis_prefix = constants.RedisPrefixSysAdminVcharge; next();});
// app.use('/servicesysadmin', function (req, res, next){req.query.service_db_name_suffix = constants.vlive_gateway_db_name; next();});
// app.use('/servicesysadmin', sysadminauthapi.sysAdminAuthHandler);
// app.use('/servicesysadmin', require('./routes/servicesysadmin'));

// //Subscriber Related
// const subscriberauthapi = require('/opt/authapi/subscriberauthapi');
// const kidsprofilecheck = require('./subscriberapi/kidsprofilecheck');
// let checkSessionTokenWithKidsRestriction = [subscriberauthapi.subscriberOnlySessionHandler,kidsprofilecheck.KidsProfileCheckHandler];

// app.use('/subscriber', function (req, res, next){req.query.service_redis_prefix = constants.RedisPrefixSubscriberVcharge; next();});
// app.use('/subscriber', function (req, res, next){req.query.service_db_name_suffix = constants.db_name_suffix_vcharge; next();});
// app.use('/subscriber', subscriberauthapi.subscriberOnlySessionHandler);
// app.use('/subscriber', require('./routes/subscriber'));

// //Payment Related
// app.use('/subscriber/v1/payment/init', kidsprofilecheck.KidsProfileCheckHandler, require('./routes/subscriberpaymentinit'));

// //IOS Inapp
// app.use('/restore', function (req, res, next){req.query.service_redis_prefix = constants.RedisPrefixSubscriberVcharge; next();});
// app.use('/restore', function (req, res, next){req.query.service_db_name_suffix = constants.db_name_suffix_vcharge; next();});
// app.use('/restore', checkSessionTokenWithKidsRestriction);
// app.use('/restore', require('./routes/restore'));

// //Webhook Callbacks Related
// app.use('/callback', function (req, res, next){req.query.service_redis_prefix = constants.RedisPrefixSubscriberVcharge; next();});
// app.use('/callback', function (req, res, next){req.query.service_db_name_suffix = constants.db_name_suffix_vcharge; next();});
// app.use('/callback', require('./routes/callback'));

// //Intermdediate Callback Handler
// app.use('/pghandler', function (req, res, next){req.query.service_redis_prefix = constants.RedisPrefixSubscriberVcharge; next();});
// app.use('/pghandler', function (req, res, next){req.query.service_db_name_suffix = constants.db_name_suffix_vcharge; next();});
// app.use('/pghandler', require('./routes/pghandler'));

// //PG Client Callback Handler Needs to delete
// app.use('/pgclienthandler', function (req, res, next){req.query.service_redis_prefix = constants.RedisPrefixSubscriberVcharge; next();});
// app.use('/pgclienthandler', function (req, res, next){req.query.service_db_name_suffix = constants.db_name_suffix_vcharge; next();});
// app.use('/pgclienthandler', checkSessionTokenWithKidsRestriction);
// app.use('/pgclienthandler', require('./routes/pgclienthandler'));

// //Renewhandler Undocumented API Needs to delete after Cron-Re-Write
// app.use('/renewalhandler', function (req, res, next){req.query.service_redis_prefix = constants.RedisPrefixSubscriberVcharge; next();});
// app.use('/renewalhandler', function (req, res, next){req.query.service_db_name_suffix = constants.db_name_suffix_vcharge; next();});
// app.use('/renewalhandler', providerauthapi.providerAuthHandler);
// app.use('/renewalhandler', require('./routes/renewalhandler'));

// //Telco Related External API
// app.use('/externalapi', function (req, res, next){req.query.service_redis_prefix = constants.RedisPrefixSubscriberVcharge; next();});
// app.use('/externalapi', function (req, res, next){req.query.service_db_name_suffix = constants.db_name_suffix_vcharge; next();});
// app.use('/externalapi', subscriberauthapi.subscriberAuthHandler);
// app.use('/externalapi', require('./routes/externalpaymentinit'));

// //IOS Inapp
// app.use('/payment', function (req, res, next){req.query.service_redis_prefix = constants.RedisPrefixSubscriberVcharge; next();});
// app.use('/payment', function (req, res, next){req.query.service_db_name_suffix = constants.db_name_suffix_vcharge; next();});
// app.use('/payment', checkSessionTokenWithKidsRestriction);
// app.use('/payment', require('./routes/payment'));

// //Invalid Endpoint Handling
// app.use('*', function (req, res){res.status(400).json({ errorcode: 1404, reason: req.method + ' ' + req.originalUrl + ' not found' });});

var createError = require('http-errors');
var express = require('express');
var path = require('path');
// var cookieParser = require('cookie-parser');
var logger = require('morgan');
// var multer = require('multer');
// var storage = multer.memoryStorage()
// var upload = multer({ storage: storage })
//var bodyParser = require('body-parser');
var indexRouter = require('./routes/index');
var eventRouter = require('./routes/events');
const serverless = require('serverless-http');
var app = express();
var cors = require('cors');
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(cors());
app.options('*', cors());

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// app.use(bodyParser.json()); // support json encoded bodies
// app.use(bodyParser.urlencoded({ extended: false })); // support encoded bodies

// To parse Form Data
//app.use(upload.array()); 

// app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/test', indexRouter);
app.use('/event', eventRouter);

// // catch 404 and forward to error handler
// app.use(function(req, res, next) {
//   next(createError(404));
// });

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

//Final Router
module.exports.handler = serverless(app);