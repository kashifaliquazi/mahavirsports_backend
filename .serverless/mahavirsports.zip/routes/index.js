var express = require('express');
var router = express.Router();


router.get('/test', function(req, res, next) {
  console.log("Express test to test the Endpont 111111111111",req.url)

/ res.send({ title: 'Express test' });
});
/* GET home page. */
router.post('/asd', function(req, res, next) {
  console.log("Express test to test the Endpont 111111111111",req.url)

  req.url ='/new2';
  req.testData= "kashif";
  next();
  res.send({ title: 'Express test' });
});

router.post('/new2', function(req, res, next) {
  console.log("Express test to test the Endpont 222222222")
 // next();
  res.send({ title: 'Express test new2'+req.testData });
});

router.post('/asd', function(req, res, next) {
  console.log("Express test to test the Endpont 3333333333")
  res.send({ title: 'Express test eew' });
});


module.exports = router;
