// const { Mobile } = require("aws-sdk");
// const PubNub = require("PubNub");
// let pubnub = new PubNub({
//     publishKey : "pub-c-b1ef8bb6-4a2e-4c4b-9976-4168d266d16e",
//     subscribeKey : "sub-c-3b3b0e8a-1dbd-11e7-aca9-02ee2ddab7fe",
//     uuid: "myUniqueUUID"
//   })

  module.exports.pubnub = {};
