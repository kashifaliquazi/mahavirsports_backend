const { CONSTANTS } = require('./constants');

const MongoClient = require('mongodb').MongoClient;


var cachedConnection = null;
module.exports.getConnection = async () =>{
  if(cachedConnection && cachedConnection.isConnected()){
    console.log("reusing Connetion in frequent calls");
  return cachedConnection;
  }
  
  const uri = CONSTANTS.uri;//zxt5 "mongodb+srv://boris:Boris@123@cluster0-6fm0w.mongodb.net/Boris?retryWrites=true";
  console.log("Inside Get Connwction",uri);
  const client = new MongoClient(uri, { useNewUrlParser: true,poolSize: 10 });
  await client.connect();
  cachedConnection = client;
  return cachedConnection;
}

